﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
class own : Exception

{
    public own(string Message) : base(Message)
        {
    }
    public own()
        {
    }
    public own(string Message, Exception inside) : base(Message, inside)
    {

    }

}

namespace Own_Exception
{

    class Program
    {
        static void Main(string[] args)
        {
            int x = 5, y = 2000;
            try
            {
                float z = (float)x / (float)y;
                if (z < 0.01)
                {
                    throw new own("Number is too small");
                }
            }
            catch (own e)
            {
                Console.WriteLine("Exception caught ");
                Console.WriteLine(e.Message);
            }
            finally
            {
                Console.WriteLine("This value is here");
            }
            Console.ReadLine();
        }
    }
}