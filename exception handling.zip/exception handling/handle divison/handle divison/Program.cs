﻿using System;

class DivisionExample
{
    static void Main()
    {
        try
        {
            Console.Write("Enter numerator: ");
            int numerator = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter denominator: ");
            int denominator = Convert.ToInt32(Console.ReadLine());

            int result = numerator / denominator;

            Console.WriteLine($"Result: {result}");
        }
        catch 
        {
            Console.WriteLine("Cannot divide by zero.");
        
        }
        finally
        {
            Console.WriteLine("Program has finished attempting division.");
        }
    }
}
