﻿using System;

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Enter a number: ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Enter another number: ");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine("Result: " + (a / b));
        }
        catch
        {
            Console.WriteLine("An error occurred.");
        }
        finally
        {
            Console.WriteLine("Program ended.");
        }
    }
}
