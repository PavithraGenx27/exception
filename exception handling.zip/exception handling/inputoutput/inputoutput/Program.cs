﻿using System;

class Input
{
    static void Main()
    {
        try
        {
            Console.Write("Enter a number: ");
            int number = Convert.ToInt32(Console.ReadLine()); 
            Console.WriteLine($"You entered: {number}");
        }
        catch 
        {
            Console.WriteLine("Please enter a valid integer number.");
        }
       
    }
}