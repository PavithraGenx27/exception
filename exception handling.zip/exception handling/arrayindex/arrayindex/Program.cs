﻿using System;

class Array
{
    static void Main()
    {
        int[] numbers = { 10, 20, 30 ,40, 50};

        try
        {
            Console.WriteLine("Array elements:");
            for (int i = 0; i <= numbers.Length; i++) 
            {
                Console.WriteLine($"Element at index {i}: {numbers[i]}");
            }
        }
        catch 
        {
            Console.WriteLine("Attempted to access an index that is outside the bounds of the array.");
            
        }
        finally
        {
            Console.WriteLine("Array access attempt complete.");
        }
    }
}
